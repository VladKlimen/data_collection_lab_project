# Databricks notebook source
# pyspark
from pyspark.sql.types import *
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
from pyspark.sql import functions as F
from pyspark.sql.functions import udf, struct, lit
from pyspark.sql.functions import col
from pyspark.sql.functions import split, explode
from pyspark.ml.stat import ChiSquareTest
from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml.linalg import Vectors, VectorUDT
from pyspark.ml import Pipeline

# sparknlp
import sparknlp
from pyspark.ml import PipelineModel
from sparknlp.annotator import *
from sparknlp.base import *

# for visualization
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from IPython.core.display import display, HTML

# python standard libraries
from statistics import mean, variance
from math import log10, sqrt
from operator import add
from functools import reduce
from collections import Counter
import csv
import json
import re
import string

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 1000)
field_size_limit = csv.field_size_limit(10**9)

# COMMAND ----------

# spark = sparknlp.start(gpu=True)
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

print("Spark NLP version", sparknlp.version())
print("Apache Spark version:", spark.version)

spark

# COMMAND ----------

# Load the scraped data
with open("/Workspace/Users/vladklim@campus.technion.ac.il/Project/scraped_jobs.csv", newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    jobs_dict = {comp[0]: list(eval(comp[1])) for comp in reader}

# COMMAND ----------

import statistics
jobs_len = [len(jobs) for jobs in jobs_dict.values()]
mean = statistics.mean(jobs_len)
median = statistics.median(jobs_len)
variance = statistics.pvariance(jobs_len)
print(f"{mean=}, {median=}, {variance=}")

# COMMAND ----------

dict(sorted(Counter(jobs_len).items(), key=lambda x: x[1], reverse=True)[:10])

# COMMAND ----------

import seaborn as sns
import numpy as np

sns.histplot(jobs_len, bins=100, kde=True)
plt.xlabel("Active Job Posts Number")
plt.ylabel("Count")
plt.title("Distribution of Active Job Posts Number Over Hiring Companies")
plt.show()

# COMMAND ----------

def extract_tags(text, pattern=None, clean_pattern=None):
    if not pattern:
        pattern = r'<strong>(.*?)</strong>'
    tags = re.findall(pattern, text)
    if clean_pattern:
        tags = [re.sub(clean_pattern, "", tag.strip()).lower() for tag in tags]
        tags = [re.sub(r'[^\w\s]', "", tag) for tag in tags 
                if not all(char not in string.printable or char.isspace() for char in tag)]    # remove puncutation
        tags = [tag for tag in tags if tag != ""]
        
    return tags

# COMMAND ----------

bold_strings = []
for jobs in jobs_dict.values():
    for job in jobs:
        bold_strings += extract_tags(job['description'], clean_pattern=r'<[^>]*>')
# bold_strings = list(set(bold_strings))

# COMMAND ----------

bold_strings_counts = dict(sorted(Counter(bold_strings).items(), key=lambda x: x[1], reverse=True))
bold_strings_counts = [(key, value) for key, value in bold_strings_counts.items()]
len(bold_strings_counts)

# COMMAND ----------

df_bold_strings_counts = spark.createDataFrame(bold_strings_counts, ["sentence", "count"])


# COMMAND ----------

df_bold_strings_counts.display()

# COMMAND ----------

bold_strings

# COMMAND ----------

jobs_list = [(url, job) for url, job in jobs_dict.items()]
schema = StructType([])

# COMMAND ----------

scraped_jobs = spark.read.option("header", "true").csv("file:/Workspace/Users/vladklim@campus.technion.ac.il/Project/scraped_jobs.csv")
scraped_jobs = scraped_jobs.withColumn("jobs", F.from_json(" jobs", ArrayType(StringType()))).drop(" jobs")
companies = spark.read.parquet('/linkedin/companies')