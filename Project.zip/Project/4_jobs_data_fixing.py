# Databricks notebook source
# pyspark
from pyspark.sql.types import *
import pyspark
from pyspark.sql import SparkSession

# for visualization
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# python standard libraries
import statistics
from math import log10, sqrt
from operator import add
from functools import reduce
from collections import Counter
import csv
import json
import re
import string
import time

field_size_limit = csv.field_size_limit(10**9)

# COMMAND ----------

spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

print("Apache Spark version:", spark.version)

spark

# COMMAND ----------

with open("/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_content.csv", newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    jobs_dict = {}
    for data in reader:
        if data is not None:
            if data[1] in jobs_dict:
                jobs_dict[data[1]].append(data[2])
            else:
                jobs_dict[data[1]] = [data[2]]

jobs_dict = {url: [eval(job) for job in jobs] for url, jobs in jobs_dict.items()}

# COMMAND ----------

# Load the scraped data
with open("/Workspace/Users/vladklim@campus.technion.ac.il/Project/scraped_jobs.csv", newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    jobs_dict_raw = {comp[0]: list(eval(comp[1])) for comp in reader}

# COMMAND ----------

def jobs_stats(jobs_dict, dict_name):    
    jobs_per_comp = [len(jobs) for jobs in jobs_dict.values()]
    jobs_total = sum(jobs_per_comp)
    mean = statistics.mean(jobs_per_comp)
    median = statistics.median(jobs_per_comp)
    variance = statistics.variance(jobs_per_comp)
    print(f"{dict_name}:\n\t{len(jobs_dict)=}, {jobs_total=}, {mean=}, {median=}, {variance=}")
    return {"jobs_per_comp": jobs_per_comp, "jobs_total": jobs_total, "mean": mean, "median": median, "var": variance}

# COMMAND ----------

jobs_raw_stats = jobs_stats(jobs_dict_raw, "jobs_dict_raw")
jobs_parsed_stats = jobs_stats(jobs_dict, "jobs_dict")

# COMMAND ----------

dict(sorted(Counter(jobs_raw_stats["jobs_per_comp"]).items(), key=lambda x: x[1], reverse=True)[:10])

# COMMAND ----------

dict(sorted(Counter(jobs_parsed_stats["jobs_per_comp"]).items(), key=lambda x: x[1], reverse=True)[:10])

# COMMAND ----------

sns.histplot(jobs_parsed_stats["jobs_per_comp"], bins=100, kde=True)
plt.xlabel("Active Job Posts Number")
plt.ylabel("Count")
plt.title("Distribution of Parsed Job Posts Number Over Hiring Companies")
plt.show()

# COMMAND ----------

contents = {}
for url, jobs_list in jobs_dict.items():
    for index, job in enumerate(jobs_list):
        for key, value in job.items():
            if key in contents:
                contents[key].append(str(value).lower().replace('.', ''))
            else:
                contents[key] = [str(value).lower().replace('.', '')]

# COMMAND ----------

list(contents.keys())

# COMMAND ----------

contents_counts = {key: dict(sorted(Counter(contents[key]).items(), key=lambda x: x[1], reverse=True)) for key in contents}

# COMMAND ----------

contents_keys = list(contents.keys())
print(contents_keys[2])
filtered_counts = {key: value for key, value in contents_counts[contents_keys[2]].items() if value > 1 and len(key) <= 50}
print(len(filtered_counts))
filtered_counts

# COMMAND ----------

bad_content = ['n/a', 'none', 'na', ' ']
bad_content_substr = ['not mentioned', 'not specified', 'not provided', 'none specified', 'no info',
               'none provided', 'no information provided', 'none mentioned', 'not available', 'no data',
               'not explicitly stated', 'unprovided']

# COMMAND ----------

 job_keys = {
    'Job Title and Summary': "",
    'Company Overview': "",
    'Job Responsibilities': [],
    'Qualifications and Skills': [],
    'Required Education': "",
    'Benefits and Perks': [],
    'Application Process': "",
    'Contact Information': ""
    }

# COMMAND ----------

for url, jobs_list in jobs_dict.items():
    for index, job in enumerate(jobs_list):
        for key, value in job.items():
            value_str = str(value).lower().replace('.', '')
            if key in job_keys and \
            (any(value_str == bad for bad in bad_content) \
             or any(bad in value_str for bad in bad_content_substr) \
             or type(value) != type(job_keys[key])):
                jobs_dict[url][index][key] = job_keys[key]
        for key in job_keys:
            if key not in job:
                jobs_dict[url][index][key] = job_keys[key]

# COMMAND ----------

incorrect_jobs = {}
for url, jobs_list in jobs_dict.items():
    for index, job in enumerate(jobs_list):
        for key in job:
            if key not in job_keys:
                if url in incorrect_jobs:
                    incorrect_jobs[url].append({index: key})
                else:
                    incorrect_jobs[url] = [{index: key}]
            elif type(job[key]) != type(job_keys[key]):
                if url in incorrect_jobs:
                    incorrect_jobs[url].append({index: (key, job[key])})
                else:
                    incorrect_jobs[url] = [{index: (key, job[key])}]

# COMMAND ----------

incorrect_jobs

# COMMAND ----------

renamed_job_keys = {
    'Job Title and Summary': "title_and_summary",
    'Company Overview': "company_overview",
    'Job Responsibilities': "responsibilities",
    'Qualifications and Skills': "qualifications_and_skills",
    'Required Education': "education",
    'Benefits and Perks': "benefits",
    'Application Process': "application",
    'Contact Information': "contact_info"
    }

# COMMAND ----------

for url, jobs_list in jobs_dict.items():
    for i, job in enumerate(jobs_list):
        for key in renamed_job_keys:
            jobs_dict[url][i][renamed_job_keys[key]] = jobs_dict[url][i].pop(key)

# COMMAND ----------

for url, jobs_list in jobs_dict.items():
    for i, job in enumerate(jobs_list):
        for key in other_keys:
            try:
                jobs_dict[url][i][key] = jobs_dict_raw[url][i][key]
            except:
                print(f"{url=}, {len(jobs_dict_raw[url])=}, {i=}")
                print(f"{jobs_dict[url][i]=}")

# COMMAND ----------

next(iter(jobs_dict.values()))[0].keys()

# COMMAND ----------

import pickle

jobs_pickle_path = "/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_parsed_dict.pickle"
with open(jobs_pickle_path, "wb") as f:
    pickle.dump(jobs_dict, f)

# COMMAND ----------

other_keys = ['title', 'description', 'location', 'post_time', 'criterias', 'url', 'datetime', 'benefits']
inner_schema = StructType([
    StructField(renamed_job_keys["Job Title and Summary"], StringType(), True),
    StructField(renamed_job_keys["Company Overview"], StringType(), True),
    StructField(renamed_job_keys["Job Responsibilities"], ArrayType(StringType()), True),
    StructField(renamed_job_keys["Qualifications and Skills"], ArrayType(StringType()), True),
    StructField(renamed_job_keys["Required Education"], StringType(), True),
    StructField(renamed_job_keys["Benefits and Perks"], ArrayType(StringType()), True),
    StructField(renamed_job_keys["Application Process"], StringType(), True),
    StructField(renamed_job_keys["Contact Information"], StringType(), True),
    *[StructField(key, StringType(), True) for key in other_keys]
])

outer_schema = StructType([
    StructField("url", StringType(), False),
    StructField("jobs_parsed", ArrayType(inner_schema), False)
])

jobs_parsed_df = spark.createDataFrame([(url, jobs_list) for url, jobs_list in jobs_dict.items()], ["url", "jobs_parsed"], outer_schema)
jobs_parsed_df.write.parquet("/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_parsed.parquet", mode="overwrite")


# COMMAND ----------

jobs_parsed_df.display()