# Databricks notebook source
from time import sleep
while True:
    sleep(10)