# Databricks notebook source
!pip install -q -U google-generativeai

# COMMAND ----------

# for visualization
import seaborn as sns
import numpy as np

# python standard libraries
from statistics import mean, median, variance
from math import log10, sqrt
from operator import add
from functools import reduce
from collections import Counter
import csv
import json
import re
import string

# gemini
import google.generativeai as genai

field_size_limit = csv.field_size_limit(10**9)

# COMMAND ----------

# Load the scraped data
with open("/Workspace/Users/vladklim@campus.technion.ac.il/Project/scraped_jobs.csv", newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    jobs_dict = {comp[0]: list(eval(comp[1])) for comp in reader}

# COMMAND ----------

jobs_len = [len(jobs) for jobs in jobs_dict.values()]
jobs_number = sum(jobs_len)
mean = mean(jobs_len)
median = median(jobs_len)
variance = variance(jobs_len)
print(f"{len(jobs_dict)=}, {jobs_number=}, {mean=}, {median=}, {variance=}")

# COMMAND ----------

dict(sorted(Counter(jobs_len).items(), key=lambda x: x[1], reverse=True)[:10])

# COMMAND ----------

GOOGLE_API_KEY = 'AIzaSyDlHN9s6fE-utsdrqh4fdXAWUaYhbpprNw'
genai.configure(api_key=GOOGLE_API_KEY)

# COMMAND ----------

for m in genai.list_models():
  if 'generateContent' in m.supported_generation_methods:
    print(m.name)

# COMMAND ----------

# MAGIC %md
# MAGIC dict_structure = {<br>
# MAGIC "Job Title and Summary": ...,<br>
# MAGIC "Company Overview": ...,<br>
# MAGIC "Job Responsibilities": ["responsibility 1", "responsibility 2", ...],<br>
# MAGIC "Qualifications and Skills": ["qualification 1", "qualification 2", ...],<br>
# MAGIC "Required Education": ...,<br>
# MAGIC "Benefits and Perks": ["benefit 1", "benefit 2", ...],<br>
# MAGIC "Application Process": ..., <br>
# MAGIC "Contact Information": ...<br>
# MAGIC }

# COMMAND ----------

def get_dict(response_text):
  stack = []
  start_index = None
  for i, char in enumerate(response_text):
    if char == '{':
      if start_index is None:
        start_index = i
      stack.append(char)
    elif char == '}':
      if not stack:
        return None
      stack.pop()
      if not stack:
        return eval(response_text[start_index:i + 1])  
  return None

# COMMAND ----------

model = genai.GenerativeModel('gemini-1.0-pro-latest')

# COMMAND ----------

posts = sum([[(i, url, job["description"], api_keys[i % len(api_keys)]) for i, job in enumerate(jobs)] for url, jobs in jobs_dict.items()], [])

# COMMAND ----------

max_attempts = 6
failed_inarow = 0
max_index = max([len(jobs) for jobs in jobs_dict.values()]) - 1
index = 71
start_from = 133
count = start_from
last_index = [index, count]
while index <= max_index:
    print(f"Index: {index}")
    attempts = 0
    for url, jobs in list(jobs_dict.items())[start_from:]:
        count += 1
        if index >= len(jobs):
            continue
        last_index = [index, count]
        prompt = f'''Observe the next linkedin job post: {jobs[index]["description"]}\n\n\nParse the post to the next topics: Job Title and Summary (string), Company Overview (string), Job Responsibilities (list of strings), Qualifications and Skills (list of strings), Required Education (string), Benefits and Perks (list of strings), Application Process (string), Contact Information (string). In each topic write as short as possible, only the key info. If there is nothing to put in some topic, leave it empty. Topics are keys in the python dictionary, the content of the topics after parsing are the values. In Job Responsibilities, Qualifications and Skills, Required Education, Benefits and Perks - present as list of strings, very laconically and without punctuation, each string contains only one concept (e.g only one skill) Return this dictionary, without additional information, only the dictionary.'''
        attempts = 0
        while attempts < max_attempts:
            try:
                job_content = model.generate_content(prompt)
                job_content = get_dict(job_content.text)
                with open('/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_content.csv', 'a', newline='', encoding='utf-8') as csv_file:  
                    writer = csv.writer(csv_file)
                    writer.writerow([index, url, str(job_content)])
                    
                
                print(f'{count}. {url} done')
                failed_inarow = 0
                break
            except Exception as e:
                print(index, count, e, "attempt:", attempts + 1)
                attempts += 1
                time.sleep(10)
        if attempts == max_attempts:
            with open('/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_content_failed.csv', 'a', newline='', encoding='utf-8') as csv_file:  
                writer = csv.writer(csv_file)
                writer.writerow([last_index[0], last_index[1], url, jobs[index]["description"]])
            print(f'{index} {url} - no response')
            failed_inarow += 1
            if failed_inarow > 5:
                with open('/Workspace/Users/vladklim@campus.technion.ac.il/Project/last_index.txt', 'w', newline='', encoding='utf-8') as file: 
                    file.write(f'{index}, {count}, {url}')
                    print(":(")
                break
    index += 1
    start_from = 0
    count = 0
                

# COMMAND ----------

def split_file(source_file, output1, output2):
    with open(source_file, "rb") as source:
        data = source.read()
    print(len(data))
    with open(output1, "wb") as out:
         out.write(data[:len(data) // 2])
    with open(output2, "wb") as out:
         out.write(data[len(data) // 2:])

source_file = "/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_content.csv"
output1 = "/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_content_part1.bin"
output2 = "/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_content_part2.bin"

split_file(source_file, output1, output2)
print(f"File '{source_file}' split into '{output1}' and '{output2}'.")
