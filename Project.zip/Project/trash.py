# Databricks notebook source
@udf (DoubleType())
def cosine_similarity(v1, v2):
    return float(v1.dot(v2) / ((v1.norm(2) * v2.norm(2))))


@udf (DoubleType())
def euqlidean_dist(v1, v2):
    return 1 - float(v1.squared_distance(v2) ** 0.5)


def get_similarities(embeddings_df, metric=cosine_similarity, cache=True, n_partitions=100):
    embeddings_df1 = embeddings_df.withColumnRenamed("index", "index1").withColumnRenamed("embedding", "embedding1")                     
    embeddings_df2 = embeddings_df.withColumnRenamed("index", "index2").withColumnRenamed("embedding", "embedding2")
    sim_df = embeddings_df1.join(embeddings_df2, embeddings_df1["index1"] < embeddings_df2["index2"])

    if cache:
        sim_df.persist()
    
    sim_df = sim_df.repartition(n_partitions) \
                            .withColumn("similarity", metric(F.col("embedding1"), F.col("embedding2"))) \
                            .select("index1", "index2", "similarity")
    
    print("Calculating similarities...")
    sim_data = sim_df.collect()

    return sim_data


def similarities_to_dict(sim_data):  
    col1, col2 = "index1", "index2"
    sim_dict = {}

    for row in tqdm(sim_data):
        if row[col1] not in sim_dict:
            sim_dict[row[col1]] = {}
        sim_dict[row[col1]][row[col2]] = row["similarity"]
        if row[col2] not in sim_dict:
            sim_dict[row[col2]] = {}
        sim_dict[row[col2]][row[col1]] = row["similarity"]
    
    return sim_dict


def recalculate_mean_sim(elems_sim_dict, old_mean_dist, elems, new_elem):
    total = len(elems) * (len(elems) + 1) * 0.5 - len(elems)
    new_total = (len(elems) + 1) * (len(elems) + 2) * 0.5 - (len(elems) + 1)
    new_mean_dist = old_mean_dist * total
    for old_elem in elems:
        try:
            new_mean_dist += elems_sim_dict[new_elem][old_elem]
        except Exception as e:
            new_mean_dist += elems_sim_dict[old_elem][new_elem]
    new_mean_dist /= new_total
    return new_mean_dist


# COMMAND ----------

# some indian-style code... but it (mostly) works
def cluster_sentences(sent_to_ind_map, sim_dict, min_sim=0.85, min_sim_threshold=0.8, min_sim_dec_step=0.01,
                      min_mean_sim=0.75, min_mean_sim_threshold=0.7, min_mean_sim_dec_step=0.01):
    indexes_dict = {index: {"cluster": None} for index in sent_to_ind_map}
    print(f"Sentences to cluster: {len(indexes_dict)}")
    indexes_iter = iter(indexes_dict)

    clusters = {}
    noise = {}
    cluster_num = 0
    get_next = True
    iters = 0
    clustered = 0

    prev_epoch_clustered = 0
    start = time.time()
    while clustered < len(indexes_dict):  
        try:
            if get_next:
                current_index = next(indexes_iter)
            if indexes_dict[current_index]["cluster"] is not None:
                get_next = True
                continue
            
            sorted_sim = sorted(((value, key) for key ,value in sim_dict[current_index].items() 
                                 if indexes_dict[key]["cluster"] is None), reverse=True)
            if len(sorted_sim) == 0:
                get_next = True
                continue

            max_current_sim, closest_to_current = sorted_sim[0]
            # Case: no unclustered sentence close enough to the current sentence
            if max_current_sim < min_sim:
                get_next = True
                sorted_sim_clustered = sorted(((value, key) for key ,value in sim_dict[current_index].items() 
                                    if indexes_dict[key]["cluster"] is not None and indexes_dict[key]["cluster"] != -1), reverse=True)
                
                # Subcase: but there is a clustered sentence close enough to the current
                if len(sorted_sim) > 0:
                    new_mean_sim = 1
                    i = 0

                    # Find cluster to which the current sentence is similar enough
                    while new_mean_sim >= min_mean_sim and i < len(sorted_sim_clustered):
                        max_current_sim, closest_to_current = sorted_sim_clustered[i]
                        i += 1
                        # Oops, no sentence similar enough
                        if max_current_sim < min_sim:
                            break
                        
                        closest_cluster_num = indexes_dict[closest_to_current]["cluster"]
                        new_mean_sim = recalculate_mean_sim(sim_dict, clusters[closest_cluster_num]["mean_dist"], 
                                                        clusters[closest_cluster_num]["indexes"], current_index)
                        # Subcase: found cluster close eoungh to the sentence
                        if new_mean_sim >= min_mean_sim:
                            clustered += 1
                            clusters[closest_cluster_num]["mean_dist"] = new_mean_sim
                            clusters[closest_cluster_num]["indexes"].append(current_index)
                            indexes_dict[current_index]["cluster"] = indexes_dict[closest_to_current]["cluster"]
                            break

            # Case: there is a sentence that close enough to the current sentence    
            else:
                # Subcase: new cluster
                if cluster_num not in clusters:
                    clustered += 2
                    clusters[cluster_num] = {"mean_dist": max_current_sim, "indexes": [current_index, closest_to_current]}
                    indexes_dict[current_index]["cluster"] = cluster_num
                    indexes_dict[closest_to_current]["cluster"] = cluster_num
                    current_index = closest_to_current
                    get_next = False
                
                # Subcase: existing cluster, the current sentence is in it, trying to find the closest sentence to both the current sentence
                # and the cluster
                else: 
                    new_mean_sim = 1
                    i = 1
                    while new_mean_sim >= min_mean_sim and i < len(sorted_sim):
                        new_mean_sim = recalculate_mean_sim(sim_dict, clusters[cluster_num]["mean_dist"], 
                                                        clusters[cluster_num]["indexes"], closest_to_current)
                        # The closest sentence found
                        if new_mean_sim >= min_mean_sim:
                            clustered += 1
                            clusters[cluster_num]["mean_dist"] = new_mean_sim
                            clusters[cluster_num]["indexes"].append(closest_to_current)
                            indexes_dict[closest_to_current]["cluster"] = cluster_num
                            current_index = closest_to_current
                            get_next = False
                            break
                        
                        # Still not found, continue searching
                        max_current_sim, closest_to_current = sorted_sim[i]
                        i += 1
                        if max_current_sim < min_sim:
                            break
                    
                    # Not found sentence close enough both to the current sentence and it's cluster, the current cluster is formed,
                    # create a new cluster
                    if indexes_dict[closest_to_current]["cluster"] is None:
                        get_next = True
                        cluster_num += 1

        except StopIteration:
            iters += 1
            if time.time() - start > 5:
                print(f'''Iterations: {iters}''', end=('\r'))
                start = time.time()
            
            if clustered == prev_epoch_clustered:
                min_mean_sim -= min_mean_sim_dec_step
            stop = False
            if round(min_mean_sim, 2) < min_mean_sim_threshold:
                min_sim -= min_sim_dec_step
                if round(min_sim, 2) < min_sim_threshold:
                    for key in {key: value for key, value in indexes_dict.items() if value["cluster"] is None}:
                        clustered += 1
                        indexes_dict[key]["cluster"] = -1
                        if -1 not in clusters:
                            clusters[-1] = {"mean_dist": 0, "indexes": [key]}
                        else:
                            clusters[-1]["indexes"].append(key)
                    stop = True
            if stop:
                break
            else:
                prev_epoch_clustered = clustered
                indexes_iter = iter(sim_dict)

    print(f'''Iterations: {iters}''', end=('\r'))
    print(f'''\nClustered: {clustered}, Noise: {len(clusters[-1]["indexes"]) 
          if -1 in clusters else 0}, Total clusters: {len(clusters)}''')
    # print("\nFinished")
    return clusters, indexes_dict, noise

# COMMAND ----------

def get_similarities_dict(embeddings_dict, metric=cosine_similarity, cache=False, save_pickle=True, from_pickle=True, pickle_folder="", 
                      pickle_path="/Workspace/Users/vladklim@campus.technion.ac.il/Project/similarities_dicts/"):
    if save_pickle and not os.path.exists(os.path.join(pickle_path, pickle_folder)):
        os.makedirs(os.path.join(pickle_path, pickle_folder))

    similarities_dict = {}
    for i, category in enumerate(sorted(list(embeddings_dict.keys()))):
        print(f"\nCategory: {category}")
        calculated = False
        success = False
        if from_pickle:
            try:
                with open(os.path.join(pickle_path, pickle_folder, 
                                       f'''similarities_{category.lower().replace(" ", "_")}.pickle'''), "rb") as f:
                    similarities_dict[category] = pickle.load(f)
                print(f"{category} - succsessfully loaded from pickle.")
                success = True
            except:
                print(f"{category} - failed to load from pickle, performing calcuclations...")
                
        if not success:
            try:
                similarities_data = get_similarities(embeddings_dict[category], metric=metric, cache=cache)
                similarities_dict[category] = similarities_to_dict(similarities_data)
                print(f"{category} - successfully calculated similarities.")
                calculated = True
            except Exception as e:
                print(e)
                print(f"{category} - failed to calculate, skipping...")
                break

        if calculated and save_pickle:
            try:
                with open(os.path.join(pickle_path, pickle_folder, 
                                       f'''similarities_{category.lower().replace(" ", "_")}.pickle'''), "wb") as f:
                    pickle.dump(similarities_dict, f)
                print(f"{category} - successfully saved to pickle.")
            except:
                print(f"{category} - failed to save to pickle, try to save from output.")
    print("\nFinished.")

    return similarities_dict


def get_clusters_dict(sent_to_ind_map, similarities_dict, save_pickle=True, from_pickle=True, 
                      min_sim=0.85, min_sim_threshold=0.8, min_sim_dec_step=0.01,
                      min_mean_sim=0.75, min_mean_sim_threshold=0.7, min_mean_sim_dec_step=0.01,
                      pickle_name="clusters_dict.pickle", 
                      pickle_path="/Workspace/Users/vladklim@campus.technion.ac.il/Project/clusters_dicts/"):
    if save_pickle and not os.path.exists(pickle_path):
        os.makedirs(pickle_path)

    clusters_dict = {}
    if from_pickle:
        try:
            with open(os.path.join(pickle_path, pickle_name), "rb") as f:
                clusters_dict = pickle.load(f)
            print(f"Succsessfully loaded from pickle.")
            return clusters_dict
        except:
            print(f"Failed to load from pickle, performing calcuclations...")

    print("Clustering started...")
    for category in sorted(list(similarities_dict.keys())):
        print(f"\nCategory: {category}")
        clusters_dict[category] = cluster_sentences(sent_to_ind_map[category], similarities_dict[category],
                    min_sim=min_sim, min_sim_threshold=min_sim_threshold, min_sim_dec_step=min_sim_dec_step,
                    min_mean_sim=min_mean_sim, min_mean_sim_threshold=min_mean_sim_threshold, min_mean_sim_dec_step=min_mean_sim_dec_step)
    
    if save_pickle:
        try:
            with open(os.path.join(pickle_path, pickle_name), "wb") as f:
                    pickle.dump(clusters_dict, f)
            print(f"Successfully saved to pickle.")
        except:
            print(f"Failed to save to pickle, try to save from output.")

    print("\nFinished")
    
    return clusters_dict


# COMMAND ----------

@udf (VectorUDT())
def elementwise_avg(vectors):
    num_vectors = len(vectors)
    vector_size = len(vectors[0])
    avg_values = [0.0] * vector_size

    for vector in vectors:
        for i in range(vector_size):
            avg_values[i] += vector[i] / num_vectors

    return Vectors.dense(avg_values)

# COMMAND ----------

categories = ["Automation Machinery Manufacturing"]
titles_embeddings_dict_trunc = {key: value for key, value in titles_embeddings_dict.items() if key in categories}

# COMMAND ----------

titles_similarities_dict = get_similarities_dict(titles_embeddings_dict_trunc, pickle_folder="titles", save_pickle=True, from_pickle=False)

# COMMAND ----------

titles_clusters_dict = get_clusters_dict(job_titles_toi, titles_similarities_dict, pickle_name="titles_clusters_dict.pickle", 
                                        min_sim=0.85, min_sim_threshold=0.75, min_sim_dec_step=0.01,
                                        min_mean_sim=0.8, min_mean_sim_threshold=0.7, min_mean_sim_dec_step=0.01, 
                                        save_pickle=True, from_pickle=False)

# COMMAND ----------

category = "Automation Machinery Manufacturing"
indexes_clusters = titles_clusters_dict[category][1]
get_cluster_udf = udf(lambda index: indexes_clusters[index]['cluster'], IntegerType())
titles_embeddings_dict[category] = titles_embeddings_dict[category] \
                                        .withColumn("cluster", get_cluster_udf(F.col("index"))).withColumn("category", F.lit(category))

centroids_df = titles_embeddings_dict[category].groupBy("cluster", "category") \
                                            .agg(elementwise_avg(F.collect_list("embedding")).alias("centroid"))

titles_embeddings_dict[category] = titles_embeddings_dict[category].join(centroids_df, ['cluster', 'category'], 'left_outer') \
                                        .withColumn("sim_to_centroid", cosine_similarity(F.col("embedding"), F.col("centroid"))) \
                                        .select("index", "sentence", "cluster", "sim_to_centroid", "category", "embedding", "centroid")
titles_embeddings_dict[category].persist()
titles_embeddings_dict[category].display()

# COMMAND ----------

def plot_jobs_hist_by_industry():    
    industries = tech_comps.select("industries").distinct().rdd.flatMap(lambda x: x).collect()

    fig, axs = plt.subplots(len(industries)+1, figsize=(10, 25))

    df = tech_comps.withColumn("jobs_number", F.size(F.col("jobs_parsed")))
    axs[0].hist(df.select("jobs_number").toPandas()["jobs_number"], bins=20, alpha=0.7)
    axs[0].set_title("All")

    for i, industry in enumerate(industries):
        data = df.filter(df["industries"] == industry).select("jobs_number").toPandas()
        axs[i+1].hist(data["jobs_number"], bins=50, alpha=0.7)
        axs[i+1].set_title(f"{industry}")

    plt.tight_layout()
    plt.show()

plot_jobs_hist_by_industry()

# COMMAND ----------

# MAGIC %md
# MAGIC clustering

# COMMAND ----------

jobs_titles_data = {}
job_titles_toi = {}
for industry in set(comps_industries.values()):
    jobs_titles_data[industry] = sum([[(url, i, f'{url}_{i}', job["title"]) for i, job in enumerate(value_dict["jobs"])] 
                                 for url, value_dict in jobs_dict.items() if value_dict["industry"] == industry], [])
    job_titles_toi[industry] = {i: title for i, title in enumerate (list(set(sum([[job["title"] for job in value_dict["jobs"]] 
                                        for value_dict in jobs_dict.values() if value_dict["industry"] == industry], []))))}
sum([len(job_titles_toi[industry]) for industry in job_titles_toi.keys()])

# COMMAND ----------

def optics_clustering(embeddings_df, 
                    metric='cosine', min_samples=3, pca=False, pca_k=50, max_eps=np.inf, xi=0.05, cluster_method="xi"):
    df, embedding_col = (embeddings_df, "embedding") if not pca else (get_PCA_components(embeddings_df, k=pca_k), "embedding_pca")
    indexed_embeddings = {row[embedding_col]: row["index"] for row in 
                          df.select("index", embedding_col).collect()}
    embeddings_list = list(indexed_embeddings.keys())

    X = np.array(embeddings_list)
    # clusters = OPTICS(min_samples=min_samples, metric=metric, 
    #                   n_jobs=-1, max_eps=max_eps, xi=xi, cluster_method=cluster_method).fit_predict(X)
    clusters = hdbscan.HDBSCAN(min_cluster_size=5, min_samples=1, cluster_selection_method='leaf',
                            metric=metric, cluster_selection_epsilon=0.75, prediction_data=True).fit_predict(X)
    
    eval_score = metrics.silhouette_score(X, clusters, metric=metric)
    print(f"Silhouette score: {eval_score}")
    eval_score = metrics.calinski_harabasz_score(X, clusters)
    print(f"Calinski-Harabasz score: {eval_score}")
    eval_score = metrics.davies_bouldin_score(X, clusters)
    print(f"Davies-Bouldin score: {eval_score}")

# COMMAND ----------

centroids_df = titles_clusters.groupBy("cluster", "category") \
                                            .agg(elementwise_avg(F.collect_list("embedding")).alias("centroid"))
titles_clusters_centroids = titles_clusters.join(centroids_df, ['cluster', 'category'], 'left_outer') \
                                        .withColumn("euclidean_dist", euqlidean_dist(F.col("embedding"), F.col("centroid"))) \
                                        .select("index", "sentence", "cluster", "soft_cluster", "euclidean_dist", "category", "embedding", "centroid")
titles_clusters_centroids.persist()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# Calculate cosine similarities
df = titles_clusters_centroids.select("centroid", "cluster").distinct().filter(F.col("cluster") != F.lit(-1))
df_cross = df.selectExpr("centroid as centroid1", "cluster as cluster1") \
            .crossJoin(df.selectExpr("centroid as centroid2", "cluster as cluster2"))
df_similarity = df_cross.withColumn("euclidean_dist", euqlidean_dist(col("centroid1"), col("centroid2")))

# Find the most similar vector for each vector in the first DataFrame
window = Window.partitionBy("centroid1").orderBy(col("euclidean_dist"))
df_most_similar = df_similarity.withColumn("rn", row_number().over(window)).filter(col("rn") == 2).drop("rn")
df_most_similar.select("cluster1", "cluster2", "euclidean_dist").orderBy("cluster1").display()


# COMMAND ----------

pickle_path = "/Workspace/Users/shalom2552@campus.technion.ac.il/project/students_skills_education_df.pickle"
with open(pickle_path, "rb") as f:
    pickle_rdd = pickle.load(f)
students_df = spark.createDataFrame(pickle_rdd)
students_df.display()