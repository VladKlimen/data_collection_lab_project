# Databricks notebook source
# MAGIC %md
# MAGIC # Part 5 - Data Analysis

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports and data loading

# COMMAND ----------

# DBTITLE 1,pip installs
!pip install hdbscan

# COMMAND ----------

# DBTITLE 1,Imports
# pyspark
from pyspark.sql.types import *
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
from pyspark.sql.functions import split, explode
from pyspark.sql import Window
from pyspark.ml.feature import StringIndexer, VectorAssembler, PCA
import pyspark.ml.feature as ftr
from pyspark.ml.linalg import Vectors, VectorUDT
from pyspark.ml import Pipeline

# nlp
import sparknlp
from sparknlp.base import *
from sparknlp.annotator import *
import nltk
from nltk import pos_tag
from nltk.tokenize import word_tokenize
import nltk.stem
from nltk.corpus import stopwords

# for visualization
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
import colorsys
from scipy.spatial import ConvexHull
from scipy.interpolate import interp1d

# python standard libraries
from statistics import mean, variance
from math import log10, sqrt
from operator import add
from functools import reduce
import builtins
import pickle
import time
from collections import defaultdict, Counter
import os
import string
import warnings
import random
from pathlib import Path
import joblib
import ast

# for clustering
from scipy.spatial import distance
import sklearn.cluster
from sklearn.cluster import OPTICS
from sklearn.manifold import TSNE
from sklearn import metrics
import hdbscan

# options
warnings.filterwarnings("ignore")
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)

# downloads
nltk.download("wordnet")
pretrained_embeddings = BertSentenceEmbeddings.pretrained('sent_bert_multi_cased', 'xx')

# COMMAND ----------

# DBTITLE 1,Spark session
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

# DBTITLE 1,Loading jobs data from the pickle, created in part 4
jobs_pickle_path = "/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_parsed_dict.pickle"
with open(jobs_pickle_path, "rb") as f:
    jobs_dict = pickle.load(f)

# COMMAND ----------

# DBTITLE 1,Creating jobs spark dataframe
renamed_job_keys = {
    'Job Title and Summary': "title_and_summary",
    'Company Overview': "company_overview",
    'Job Responsibilities': "responsibilities",
    'Qualifications and Skills': "qualifications_and_skills",
    'Required Education': "education",
    'Benefits and Perks': "benefits",
    'Application Process': "application",
    'Contact Information': "contact_info"
    }

other_keys = ['title', 'description', 'location', 'post_time', 'criterias', 'url', 'datetime', 'benefits']

inner_schema = StructType([
    StructField(renamed_job_keys["Job Title and Summary"], StringType(), True),
    StructField(renamed_job_keys["Company Overview"], StringType(), True),
    StructField(renamed_job_keys["Job Responsibilities"], ArrayType(StringType()), True),
    StructField(renamed_job_keys["Qualifications and Skills"], ArrayType(StringType()), True),
    StructField(renamed_job_keys["Required Education"], StringType(), True),
    StructField(renamed_job_keys["Benefits and Perks"], ArrayType(StringType()), True),
    StructField(renamed_job_keys["Application Process"], StringType(), True),
    StructField(renamed_job_keys["Contact Information"], StringType(), True),
    *[StructField(key, StringType(), True) for key in other_keys]
])

outer_schema = StructType([
    StructField("url", StringType(), False),
    StructField("jobs_parsed", ArrayType(inner_schema), False)
])

jobs_parsed_df = spark.createDataFrame([(url, jobs_list) for url, jobs_list in jobs_dict.items()], ["url", "jobs_parsed"], outer_schema)
# jobs_parsed_df.write.parquet("/Workspace/Users/vladklim@campus.technion.ac.il/Project/jobs_parsed.parquet", mode="overwrite")


# COMMAND ----------

# DBTITLE 1,Joining jobs data with the companies
companies = spark.read.parquet('/linkedin/companies')
tech_comps = companies.join(jobs_parsed_df, ("url"), "inner")

# COMMAND ----------

# DBTITLE 1,Jobs summary per company industry
tech_comps.withColumn("jobs_number", F.size(F.col("jobs_parsed"))).select("industries", "jobs_number").groupby("industries").agg(F.sum("jobs_number"), F.count("jobs_number")).withColumn("mean_jobs_per_company", F.round(F.col("sum(jobs_number)") / F.col("count(jobs_number)"), 1)).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Functions

# COMMAND ----------

# DBTITLE 1,Functions for sentence embeddings
# Preprocessing functions
import re
from nltk import pos_tag
from nltk.tokenize import word_tokenize


def remove_non_english_chars(text):
        return re.sub(r'[^\x00-\x7F]+', '', text).strip()
    

def remove_between_brackets(text):
    pattern = r"\([^()]*\)|\[[^\[\]]*\]|\{[^{}]*\}"
    result = re.sub(pattern, "", text)
    return result


def filter_nouns_adjectives(sentence):
    words = word_tokenize(sentence)
    tagged_words = pos_tag(words)
    filtered_words = [word for word, pos in tagged_words if pos.startswith('N') or pos.startswith('J')]
    filtered_sentence = ' '.join(filtered_words)
    return filtered_sentence


def filter_nouns_adjectives_verbs(sentence):
    words = word_tokenize(sentence)
    tagged_words = pos_tag(words)
    filtered_words = [word for word, pos in tagged_words if pos.startswith('N') or pos.startswith('J') or pos.startswith('V')]
    filtered_sentence = ' '.join(filtered_words)
    return filtered_sentence
    

@udf (StringType())
def optional_preprocess(sentence):
    prep_pipeline=[remove_non_english_chars, remove_between_brackets]
    sentence = sentence.lower()
    for func in prep_pipeline:
        sentence = func(sentence)

    return sentence

    
# Sentence embeddings
def embed_sentences(data, pretrained_embeddings, remove_stopwords=True, clean=True):
    data = data.withColumn("sentence_cleaned", optional_preprocess(F.col("sentence")))
    data = data.withColumn("sentence_cleaned", F.regexp_replace(F.col("sentence_cleaned"), r"[^a-zA-Z+#/-_ ]", ""))

    keep_stopwords = ["it"]
    english_stopwords = [word for word in stopwords.words('english') if word not in keep_stopwords]

    tokenizer = ftr.Tokenizer(inputCol="sentence_cleaned", outputCol="tokenized")
    data = tokenizer.transform(data)

    remover = ftr.StopWordsRemover(inputCol="tokenized", outputCol="filtered", stopWords=english_stopwords)
    data = remover.transform(data).withColumn("sentence_cleaned", F.concat_ws(" ", F.col("filtered")))
    
    documentAssembler = DocumentAssembler().setInputCol("sentence_cleaned").setOutputCol("document")

    embeddings = pretrained_embeddings.setInputCols(["document"]).setOutputCol("sentence_embeddings")

    pipeline = Pipeline().setStages([
        documentAssembler,
        embeddings
    ])

    result = pipeline.fit(data).transform(data)

    result = result.select("index", "sentence", "sentence_cleaned", "sentence_embeddings") \
            .withColumn("embedding_raw", F.expr("transform(sentence_embeddings, x -> x.embeddings)")).drop("sentence_embeddings")

    array_to_vector_udf = udf(lambda x: Vectors.dense(x[0]), VectorUDT())
    result = result.select("index", "sentence", "sentence_cleaned", "embedding_raw").withColumn("embedding", array_to_vector_udf(F.col("embedding_raw"))).drop("embedding_raw")

    # normalizer = ftr.Normalizer(p=2.0).setInputCol("embedding_raw").setOutputCol("embedding")
    # result = normalizer.transform(result).select("index", "sentence", "sentence_cleaned", "embedding")

    return result


def get_sentence_embeddings_dict(sent_dict, pretrained_embeddings, cache=True, n_partitions=100):
    sentence_embeddings_dict = {}
    sent_tuples = {category: [(index, sent) for index, sent in sent_dict[category].items()] for category in sent_dict.keys()}
    schema = StructType([StructField("index", IntegerType(), True), StructField("sentence", StringType(), True)])

    for category in sent_tuples.keys():
        data = spark.createDataFrame(sent_tuples[category], schema) \
                    .dropDuplicates(["sentence"])\
                    .repartition(n_partitions)
        embeddings_df = embed_sentences(data, pretrained_embeddings)

        sentence_embeddings_dict[category] = embeddings_df.persist() if cache else embeddings_df

    return sentence_embeddings_dict

# COMMAND ----------

# DBTITLE 1,Functions for clustering
def get_PCA_components(embeddings_df, inputCol="embedding", outputCol="embedding_pca", k=50):
    pca = PCA(k=k, inputCol=inputCol).setOutputCol(outputCol)
    df_pca = pca.fit(embeddings_df).transform(embeddings_df)
    return df_pca


def hdbscan_clustering(embeddings_df, metric='precomputed', min_samples=2, min_cluster_size=5, cluster_selection_method='leaf',
                           cluster_selection_epsilon=0.75, prediction_data=True, pca=False, pca_k=50):
        
    df, embedding_col = (embeddings_df, "embedding") if not pca \
                                                    else (get_PCA_components(embeddings_df, k=pca_k), "embedding_pca")
    indexed_embeddings = {row[embedding_col]: row["index"] for row in 
                                        df.select("index", embedding_col).collect()}
    embeddings_list = list(indexed_embeddings.keys())

    X = np.array(embeddings_list)

    if metric == "precomputed":
        X = metrics.pairwise.cosine_similarity(X, X)
        np.fill_diagonal(X, 0)
    
    clusterer = hdbscan.HDBSCAN(min_cluster_size=min_cluster_size, min_samples=min_samples, 
                                cluster_selection_method=cluster_selection_method, metric=metric, cluster_selection_epsilon=cluster_selection_epsilon, prediction_data=prediction_data,
                                gen_min_span_tree=True).fit(X)
    
    clusters = clusterer.labels_
    probs = clusterer.probabilities_
    all_points_membership_vectors = hdbscan.all_points_membership_vectors(clusterer)
    soft_clusters = [np.argmax(x) for x in all_points_membership_vectors]
    soft_probs = [np.max(x) for x in all_points_membership_vectors]
    
    eval_score = metrics.silhouette_score(X, clusters, metric=metric)
    print(f"Silhouette score: {eval_score}")
    eval_score = metrics.calinski_harabasz_score(X, clusters)
    print(f"Calinski-Harabasz score: {eval_score}")
    eval_score = metrics.davies_bouldin_score(X, clusters)
    print(f"Davies-Bouldin score: {eval_score}")
    
    try:
        eval_score = clusterer.relative_validity_
        print(f"DBCV relative score: {eval_score}")
    except Exception as e:
        print(f"DBCV:\n{e}")
    print(f"Number of clusters: {len(set(clusters)) - 1}")
    print(f"Number of points clustered: {len([x for x in clusters if x != -1])}")


    clusters_map = [(indexed_embeddings[embeddings_list[i]], int(cluster), int(soft_cluster), 
                     float(probability), float(soft_probability)) 
                    for i, (cluster, soft_cluster, probability, soft_probability) 
                    in enumerate(zip(clusters, soft_clusters, probs, soft_probs))]
    clusters_map_df = spark.createDataFrame(clusters_map, ["index", "cluster", "soft_cluster", "probability", "soft_probability"])

    df_clustered = df.join(clusters_map_df, "index", "inner")

    return df_clustered, clusterer


def get_tnse_embeddings(df_clustered, inputCol="embedding", metric='cosine', 
                            random_state=None, early_exaggeration=12, perplexity=20):
    df = df_clustered
    if len(df_clustered.first().asDict()[inputCol]) > 50:
        df = get_PCA_components(df_clustered, inputCol=inputCol, outputCol="output_PCA", k=50)

    vectors = df.select(inputCol).rdd.map(lambda x: tuple(x[inputCol].toArray())).collect()
    vectors = TSNE(perplexity=perplexity, early_exaggeration=early_exaggeration,
                   metric=metric, n_jobs=-1, random_state=random_state).fit_transform(vectors)

    clusters = df.select("cluster").rdd.map(lambda x: x["cluster"]).collect()
    probs = df.select("probability").rdd.map(lambda x: x["probability"]).collect()
    soft_clusters = df.select("soft_cluster").rdd.map(lambda x: x["soft_cluster"]).collect()
    soft_probs = df.select("soft_probability").rdd.map(lambda x: x["soft_probability"]).collect()

    return vectors, clusters, soft_clusters, probs, soft_probs


def generate_n_unique_colors(indexes, saturation=1, lightness="random"):
        saturation = random.uniform(0.9, 1) if saturation == "random" else saturation
        lightness = random.uniform(0.2, 0.3) if lightness == "random" else lightness

        colors = {}
        for i in indexes:
            r, g, b = colorsys.hls_to_rgb(random.uniform(0, 1), lightness, saturation)
            r_hex = int(r * 255)
            g_hex = int(g * 255)
            b_hex = int(b * 255)
            color_code = "#{:02x}{:02x}{:02x}".format(r_hex, g_hex, b_hex)
            colors[i] = color_code
        return colors


def visualize_tsne_clusters(vectors, clusters, probs, subtitle, soft_clusters=None, soft_probs=None, show_soft_clusters=True,
                            show_noise=False, annotate=True, show_simplices=True, clusters_to_show=[], fig_size=(10, 10), s=200, fontsize=10, satur_accent=1, cent_prob=0.99):
    x_coords, y_coords = zip(*vectors)
    x_coords, y_coords = np.array(x_coords), np.array(y_coords)
    centroids = {cluster: (np.mean(np.array([x for i, x in enumerate(x_coords) if clusters[i] == cluster and probs[i] > cent_prob])),
                           np.mean(np.array([y for i, y in enumerate(y_coords) if clusters[i] == cluster and probs[i] > cent_prob])))
                 for cluster in set(clusters)}
    
    if len(clusters_to_show) == 0:
        clusters_to_show =  clusters
    unique_clusters = list(set([x for x in clusters if x != -1]))
    
    # Calculate convex hulls for each cluster
    hulls = {}
    for i, cluster in enumerate(unique_clusters):
        cluster_points = np.array([vector for i, vector in enumerate(vectors)  if clusters[i] == cluster])
        try:
            hull = ConvexHull(cluster_points)
            hull_points = np.vstack([cluster_points[hull.vertices], cluster_points[hull.vertices[0]]])
            hulls[i] = hull_points
        except:
             hulls[i] = None

    # Interpolate hull points to create smooth area
    smooth_hulls = {}
    for i in range(len(unique_clusters)):
        hull_points = hulls[i]
        if hull_points is not None:
            x, y = hull_points[:, 0], hull_points[:, 1]
            t = np.linspace(0, 1, len(x))
            interp = interp1d(t, np.vstack([x, y]), kind='cubic', axis=1)
            t_smooth = np.linspace(0, 1, 100)
            smooth_points = interp(t_smooth).T
            smooth_hulls[i] = smooth_points
        else:
            smooth_hulls[i] = None

    color_palette = generate_n_unique_colors(unique_clusters)
    color_palette = {key: (value if key in clusters_to_show else 'white') for key, value in color_palette.items()}
    color_palette[-1] = (0.5, 0.5, 0.5)
    zorders = {key: (2 if key in clusters_to_show else 0) for key in clusters}
    alphas = {"cluster": 0.1, "soft_cluster": 0.1, "noise": 0.03}

    cluster_colors = [color_palette[x] for x in clusters]
    cluster_member_colors = [sns.desaturate(x, p) for x, p in zip(cluster_colors, probs)]
    
    plt.figure(figsize=fig_size)
    if show_noise:
        for i, (x, y, cluster) in enumerate(zip(x_coords, y_coords, clusters)):
            if cluster == -1:
                plt.scatter(x, y, color=cluster_member_colors[i], alpha=alphas["noise"], s=s/2, zorder=1)

    if show_soft_clusters and soft_clusters is not None and soft_probs is not None:
        alphas["cluster"] = alphas["soft_cluster"] * 2
        soft_cluster_colors = [sns.desaturate(color_palette[x], min(1, p * satur_accent)) for x, p in zip(soft_clusters, soft_probs)]
        for i, (x, y, soft_cluster) in enumerate(zip(x_coords, y_coords, soft_clusters)):
            if clusters[i] == -1 and soft_cluster in clusters_to_show:
                plt.scatter(x, y, color=soft_cluster_colors[i], alpha=alphas["soft_cluster"], s=s, zorder=3)
                
    for i, (x, y, cluster) in enumerate(zip(x_coords, y_coords, clusters)):
        if cluster != -1:
            plt.scatter(x, y, color=cluster_member_colors[i], alpha=alphas["cluster"], s=s, zorder=zorders[cluster])
    
    for i, cluster in enumerate(unique_clusters):
        x, y = centroids[cluster]
        smooth_points = smooth_hulls[i]
        if show_simplices and smooth_points is not None:
            plt.fill(smooth_points[:, 0], smooth_points[:, 1], color=color_palette[cluster], alpha=0.05, zorder=zorders[cluster])
        if annotate:
            plt.text(x, y, str(cluster), color=color_palette[cluster], ha='center', va='center', 
                     fontsize=fontsize, zorder=zorders[cluster])

    plt.title(f"2D Approximate Relative Visual Representation of Clusters ([0-{max(clusters)}])\n({subtitle})", 
              fontsize=fig_size[0] + 3)
    plt.xticks([])
    plt.yticks([])
    plt.show()

# COMMAND ----------

# DBTITLE 1,UDF functions
@udf (VectorUDT())
def elementwise_avg(vectors):
    num_vectors = len(vectors)
    vector_size = len(vectors[0])
    avg_values = [0.0] * vector_size

    for vector in vectors:
        for i in range(vector_size):
            avg_values[i] += vector[i] / num_vectors

    return Vectors.dense(avg_values)


@udf (DoubleType())
def cosine_similarity(v1, v2):
    return float(v1.dot(v2) / ((v1.norm(2) * v2.norm(2))))


@udf (DoubleType())
def euqlidean_dist(v1, v2):
    return float(v1.squared_distance(v2) ** 0.5)


@udf (ArrayType(StringType()))
def get_first_n(arr, n, start_from):
    return list(arr)[start_from : n]


@udf (ArrayType(StringType()))
def string_to_list(list_string):
    return [s.strip() for s in list_string[1:-1].split(r', ')]


@udf (StringType())
def filter_nouns(sentence):
    words = word_tokenize(sentence)
    tagged_words = pos_tag(words)
    filtered_words = [word for word, pos in tagged_words if pos.startswith('N')]
    filtered_sentence = ' '.join(filtered_words)
    return filtered_sentence

# COMMAND ----------

# DBTITLE 1,utilites
def save_to_pickle(data, file_name, dest_dir="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/"):
    Path("/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/").mkdir(parents=True, exist_ok=True)
    file_path = os.path.join(dest_dir, file_name)
    with open(file_path, "wb") as f:
        pickle.dump(data, f)


def split(source, dest_dir, files_name, write_size=10**7):
    if not os.path.exists(dest_dir):
        os.mkdir(dest_dir)
    else:
        for file in os.listdir(dest_dir):
            os.remove(os.path.join(dest_dir, file))
    part_num = 0
    
    with open(source, 'rb') as input_file:
        while True:
            chunk = input_file.read(write_size)
            if not chunk:
                break
            
            part_num += 1
            file_path = os.path.join(dest_dir, files_name + str(part_num))
            
            with open(file_path, 'wb') as dest_file:
                dest_file.write(chunk)
    
    print(f"Partitions created: {part_num}")


def join(source_dir, dest_file, read_size):
    with open(dest_file, 'wb') as output_file:
        for path in os.listdir(source_dir):
            with open(path, 'rb') as input_file:
                while True:
                    bytes = input_file.read(read_size)
                    if not bytes:
                        break
                output_file.write(bytes)

# COMMAND ----------

# DBTITLE 1,Functions for creating naming layers of the clusters
def create_layers(clusters_df, min_=2, max_=5, min_word_len=2, start_from=0, lemmatize=True):
    df = clusters_df.withColumn("sentence_filtered", filter_nouns(F.col("sentence_cleaned")))

    current_sent_col = "sentence_filtered"
    current_cluster_col = "soft_cluster"

    for i in range(max_ - min_ + 1):
        words = df.withColumn("word", F.explode(F.split(F.col(current_sent_col), r"\s+|,\s*")))

        if i == 0:
            words = words.withColumn("word", F.regexp_replace("word", "[^a-zA-Z+#/]", "")) \
                            .filter(F.length(F.col("word")) >= min_word_len)

            lemmatizer = nltk.stem.WordNetLemmatizer()
            @udf (StringType())
            def lemmatize(word):
                return lemmatizer.lemmatize(word)

            if lemmatize: 
                words = words.withColumn("word", lemmatize("word"))
                    
        word_counts = words.groupBy("word", current_cluster_col).count()

        most_frequent_words = word_counts.orderBy(current_cluster_col, F.desc("count"))

        top_words_per_cluster = most_frequent_words.groupBy(current_cluster_col) \
            .agg(F.collect_list("word").alias("words")) \
            .select(current_cluster_col, F.when(F.size(F.col("words")) >= max_ - i, 
                                                F.concat_ws(", ", get_first_n(F.col("words"), F.lit(max_ - i), F.lit(start_from)))) \
            .otherwise("Unlabelled" if i == 0 else F.col(current_sent_col)).alias(f"layer_{i}"))

        if i == 0:
            clusters_range = list(range(clusters_df.agg(F.min("soft_cluster").alias("max_cluster")).collect()[0]["max_cluster"],
                            clusters_df.agg(F.max("soft_cluster").alias("max_cluster")).collect()[0]["max_cluster"] + 1))
            remaining_clusters = [row["soft_cluster"] for row in top_words_per_cluster.select("soft_cluster").distinct().collect()]
            clusters_to_supplement = [c for c in clusters_range if c not in remaining_clusters] + [-1]

            top_words_per_cluster = top_words_per_cluster.union(
                spark.createDataFrame([(c, v) for c, v in zip(clusters_to_supplement, ["Unlabelled"] * len(clusters_to_supplement))], ["soft_cluster", f"layer_{i}"]))
        
        # clusters_df = clusters_df.join(top_words_per_cluster, [current_cluster_col], "left_outer")
        if i == 0:
            df = top_words_per_cluster
            df.persist()
        else:
            df = df.join(top_words_per_cluster, [current_cluster_col], "left_outer")

        current_sent_col = current_cluster_col = f"layer_{i}"
    
    clusters_df = clusters_df.join(df, ["soft_cluster"], "left_outer")

    return clusters_df


# COMMAND ----------

# MAGIC %md
# MAGIC ## Job Positions Titles Embedding and HDBSCAN Clustering

# COMMAND ----------

# MAGIC %md
# MAGIC ### Embedding and Clustering

# COMMAND ----------

job_titles_toi = {"all": {i: title for i, title in enumerate(list(set(sum([[job["title"] for job in value_dict["jobs"]] 
                                        for value_dict in jobs_dict.values()], []))))}}
len(job_titles_toi['all'].values())

# COMMAND ----------

categories = ["all"]
titles_embeddings_dict = get_sentence_embeddings_dict(job_titles_toi, pretrained_embeddings, cache=False)
titles_clusters, titles_clusterer = hdbscan_clustering(titles_embeddings_dict[categories[0]], metric='euclidean', min_samples=2, 
                    min_cluster_size=3, cluster_selection_method='leaf', cluster_selection_epsilon=0, 
                    prediction_data=True, pca=False, pca_k=200)
titles_clusters.persist()

# COMMAND ----------

titles_tnse_vectors, titles_clusters_list, titles_sclusters_list, titles_probs_list, titles_sprobs_list = \
                                            get_tnse_embeddings(titles_clusters, perplexity=30, metric="euclidean")

# COMMAND ----------

titles_indexes = titles_clusters.select("index").rdd.map(lambda x: x["index"]).collect()
titles_clusters = titles_clusters.join(
    spark.createDataFrame([(i, Vectors.dense(v)) for i, v in zip(titles_indexes, titles_tnse_vectors)], 
                          ["index", "TNSE_vector"]),
    ["index"], "left_outer")

# COMMAND ----------

titles_clusters.select("soft_cluster").groupBy("soft_cluster").count().orderBy(F.desc("count")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Saving The Clusterer Model

# COMMAND ----------

joblib.dump(titles_clusterer, "/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/titles_clusterer.joblib")
# split(source="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/titles_clusterer.joblib",
#     dest_dir="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/titles_clusterer_parts/", 
#     files_name="titles_clusterer_part")

# COMMAND ----------

titles_clusters_layered = create_layers(titles_clusters, min_=1)
titles_clusters_layered.persist()

# COMMAND ----------

titles_clusters_layered.select("soft_cluster", "layer_4", "layer_3", "layer_2", "layer_1", "layer_0").orderBy(F.desc("layer_4"), "soft_cluster").display()


# COMMAND ----------

print(titles_clusters_layered.select("soft_cluster").distinct().count())
print(titles_clusters_layered.select("layer_0").distinct().count())
print(titles_clusters_layered.select("layer_1").distinct().count())
print(titles_clusters_layered.select("layer_2").distinct().count())
print(titles_clusters_layered.select("layer_3").distinct().count())
print(titles_clusters_layered.select("layer_4").distinct().count())

# COMMAND ----------

titles_clusters_layered = titles_clusters_layered.join(tech_jobs_df.selectExpr("title as sentence", "industries"), "sentence", "left_outer")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Saving titles clustering data to pickle (for future interactive visualization)

# COMMAND ----------

titles_layers = [titles_clusters_layered.select(f"layer_{i}").rdd.map(lambda x: x[f"layer_{i}"]).collect() for i in range(5)]
titles_layers.append(titles_clusters_layered.select("industries").rdd.map(lambda x: x["industries"]).collect())
titles_tnse = titles_clusters_layered.select(f"TNSE_vector").rdd.map(lambda x: np.array(x["TNSE_vector"])).collect()
titles_sentences = titles_clusters_layered.select(f"sentence").rdd.map(lambda x: x["sentence"]).collect()

# COMMAND ----------

save_to_pickle(titles_layers, "titles_layers.pickle")
save_to_pickle(titles_tnse, "titles_tnse.pickle")
save_to_pickle(titles_sentences, "titles_sentences.pickle")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Skills and Qualifications: Preprocessing, Embedding, Sampling and Clustering

# COMMAND ----------

# MAGIC %md
# MAGIC ### Preparing the skills data

# COMMAND ----------

# DBTITLE 1,Arranging tech jobs data
tech_jobs_df = tech_comps.withColumn("job", F.explode("jobs_parsed")) \
                    .drop("jobs_parsed") \
                    .withColumns({'title': F.col("job.title"), 
                                  'quals_and_skills': F.col("job.qualifications_and_skills"),
                                  'education': F.col("job.education"),
                                  'responsibilities': F.col("job.responsibilities"),
                                  'benefits': F.col('job.benefits'),
                                  'post_date': F.col('job.datetime'),
                                  'location': F.col("job.location"),
                                  'criterias': F.col("job.criterias"),
                                  'url': F.col("job.url")
                                  }) \
                    .selectExpr("title", "industries", "quals_and_skills", "education", "responsibilities", "benefits",
                                "post_date", "location", "criterias", "company_size", "name as comp_name", 
                                "organization_type as org_type", "specialties", "url")

# COMMAND ----------

tech_jobs_df.display()

# COMMAND ----------

skills_df = tech_jobs_df.select("title", "industries", "quals_and_skills", "comp_name") \
        .withColumn("skills_list", string_to_list("quals_and_skills")).drop("quals_and_skills") \
        .withColumn("skill", F.explode("skills_list")).drop("skills_list")
skills_df.persist()

# COMMAND ----------

categories = [
    "Software Development",
    "Computer Hardware Manufacturing",
    "E-Learning Providers",
    "Automation Machinery Manufacturing",
    "Computer and Network Security",
    "Technology, Information and Internet",
    "IT Services and IT Consulting",
    "Telecommunications",
    "Computer Networking Products",]

job_skills_toi = {category: {i: row.skill for i, row in enumerate(skills_df.select("skill", "industries") \
                            .filter(F.col("industries") == category).distinct().collect())} 
                  for category in categories}
for category in categories:
    print(f"{category}: {len(job_skills_toi[category].values())}")

# COMMAND ----------

job_skills_toi = {"all": {i: row.skill for i, row in enumerate(skills_df.select("skill").distinct().collect())}}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Skills: Preprocessing, Embedding, Sampling

# COMMAND ----------

categories = ["all"]
skills_embeddings_dict = get_sentence_embeddings_dict(job_skills_toi, pretrained_embeddings, cache=True)

# COMMAND ----------

skills_sample_fraction = 10000 / skills_embeddings_dict["all"].select("sentence_cleaned").count()
print(skills_sample_fraction)

# COMMAND ----------

skills_embeddings_sample = skills_embeddings_dict["all"].sample(withReplacement=False, fraction=skills_sample_fraction, seed=42)

# COMMAND ----------

distribution_full = skills_embeddings_dict["all"] \
            .withColumn("sentence_length", F.length(F.col("sentence"))) \
            .groupBy("sentence_length").count().orderBy("sentence_length").toPandas()
distribution_sample = skills_embeddings_sample \
            .withColumn("sentence_length", F.length(F.col("sentence"))) \
            .groupBy("sentence_length").count().orderBy("sentence_length").toPandas()

fig, axs = plt.subplots(1, 2, figsize=(12, 4))
axs[0].bar(distribution_full["sentence_length"], distribution_full["count"], align="center", alpha=0.5)
axs[0].set_xlabel("Length of skill string")
axs[0].set_ylabel("Count")
axs[0].set_title("Distripution of skill strings length - full")
axs[1].bar(distribution_sample["sentence_length"], distribution_sample["count"], align="center", alpha=0.5)
axs[1].set_xlabel("Length of skill string")
axs[1].set_ylabel("Count")
axs[1].set_title("Distripution of skill strings length - 10000 random sample")
plt.tight_layout()
plt.show()

# COMMAND ----------

skills_embeddings_sample.filter(F.length("sentence") > 100).count() # Noise

# COMMAND ----------

skills_embeddings_sample = skills_embeddings_sample.filter(F.length("sentence") <= 100)
skills_embeddings_sample.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Skills: Clustering

# COMMAND ----------

# MAGIC %md
# MAGIC #### Clustering a 10000 sample

# COMMAND ----------

skills_clusters, skills_clusterer = hdbscan_clustering(skills_embeddings_sample, metric='euclidean', min_samples=2, min_cluster_size=3, cluster_selection_method='leaf', cluster_selection_epsilon=0, prediction_data=True, pca=False, pca_k=200)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Predicting clusters for the remaining dataset with the trained clusterer

# COMMAND ----------

skills_clusters_full = skills_embeddings_dict["all"] \
                        .join(skills_clusters.drop("sentence", "sentence_cleaned", "embedding"), "index", "outer") \
                        .fillna(-1, subset=["cluster", "soft_cluster"]) \
                        .fillna(0, subset=["probability", "soft_probability"])

# COMMAND ----------

unclustered_skills_embeddings = skills_clusters_full.filter(F.col("soft_cluster") == -1).select("index", "embedding")
indexed_skills_embeddings = {row["embedding"]: row["index"] for row in unclustered_skills_embeddings.collect()}
skills_embeddings_list = list(indexed_skills_embeddings.keys())
skills_to_predict = np.array(skills_embeddings_list)

# COMMAND ----------

skills_membership_vectors = hdbscan.prediction.membership_vector(skills_clusterer, skills_to_predict)

# COMMAND ----------

skills_soft_clusters = [np.argmax(x) for x in skills_membership_vectors]
skills_soft_probs = [np.max(x) for x in skills_membership_vectors]
skills_clusters_map = {skills_embeddings_list[i]: (int(soft_cluster), float(soft_probability)) 
                    for i, (soft_cluster, soft_probability) 
                    in enumerate(zip(skills_soft_clusters, skills_soft_probs))}
get_soft_cluster_udf = F.udf(lambda embedding: skills_clusters_map[embedding][0] 
                             if embedding in skills_clusters_map else None, IntegerType())
get_soft_prob_udf = F.udf(lambda embedding: skills_clusters_map[embedding][1] 
                          if embedding in skills_clusters_map else None, FloatType())

# COMMAND ----------

skills_clusters_full_denoised = skills_clusters_full \
                    .withColumn("soft_cluster_temp", get_soft_cluster_udf(F.col("embedding"))) \
                    .withColumn("soft_prob_temp", get_soft_prob_udf(F.col("embedding"))) \
                    .withColumn("soft_cluster", F.when(F.col("soft_cluster_temp").isNull(), 
                                                       F.col("soft_cluster")).otherwise(F.col("soft_cluster_temp"))) \
                    .drop("soft_cluster_temp") \
                    .withColumn("soft_probability", F.when(F.col("soft_prob_temp").isNull(), 
                                                           F.col("soft_probability")).otherwise(F.col("soft_prob_temp"))) \
                    .drop("soft_prob_temp", "embedding", "sentence_cleaned")
skills_clusters_full_denoised.persist()

# COMMAND ----------

skills_clusters_full_denoised_fix = skills_clusters_full_denoised \
    .join(skills_clusters_full.selectExpr("index", "soft_probability as soft_prob_initial", "embedding", "sentence_cleaned"), "index", "left_outer")

# COMMAND ----------

skills_clusters_full_denoised_fix = skills_clusters_full_denoised_fix \
    .withColumn("probability", F.when(F.col("soft_prob_initial") == 0, 
                                F.col("soft_probability")).otherwise(F.col("probability"))) \
    .drop("soft_probability").withColumnRenamed("soft_prob_initial", "soft_probability") \
    .withColumn("soft_cluster", F.when((F.col("soft_probability") > 0) & (F.col("soft_probability") < 0.004), 
                                F.lit(-1)).otherwise(F.col("soft_cluster"))) \
    .withColumn("soft_cluster", F.when((F.col("probability") < 0.2), 
                                F.lit(-1)).otherwise(F.col("soft_cluster")))

# COMMAND ----------

skills_clusters_full_denoised_fix.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Saving The Clusterer Model

# COMMAND ----------

joblib.dump(skills_clusterer, "/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/skills_clusterer.joblib")

# COMMAND ----------

skills_tnse_vectors, skills_clusters_list, skills_sclusters_list, skills_probs_list, skills_sprobs_list = \
                                            get_tnse_embeddings(skills_clusters, perplexity=50, metric="euclidean")

# COMMAND ----------

skills_clusters_layered = create_layers(skills_clusters, min_=1, min_word_len=1, lemmatize=False, start_from=1)
skills_clusters_layered.persist()

# COMMAND ----------

skills_clusters_layered.select("sentence", "soft_cluster", "layer_4", "layer_3", "layer_2", "layer_1", "layer_0") \
                        .orderBy(F.desc("layer_4"), F.desc("soft_cluster")).display()

# COMMAND ----------

print(skills_clusters_layered.select("soft_cluster").distinct().count())
print(skills_clusters_layered.select("layer_0").distinct().count())
print(skills_clusters_layered.select("layer_1").distinct().count())
print(skills_clusters_layered.select("layer_2").distinct().count())
print(skills_clusters_layered.select("layer_3").distinct().count())
print(skills_clusters_layered.select("layer_4").distinct().count())

# COMMAND ----------

# skills_clusters_layered = skills_clusters_layered.join(skills_df.selectExpr("skill as sentence", "industries"), "sentence", "left_outer")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Saving skills clustering data to pickle (for future interactive visualization)

# COMMAND ----------

skills_indexes = skills_clusters_layered.select("index").rdd.map(lambda x: x["index"]).collect()
skills_clusters_layered = skills_clusters_layered.join(
    spark.createDataFrame([(i, Vectors.dense(v)) for i, v in zip(skills_indexes, skills_tnse_vectors)], 
                          ["index", "TNSE_vector"]),
    ["index"], "left_outer")

# COMMAND ----------

skills_clusters_layered.display()

# COMMAND ----------

skills_clusters_layered.display()

# COMMAND ----------

# skills_layers = [skills_clusters_layered.select(f"layer_{i}").rdd.map(lambda x: x[f"layer_{i}"]).collect() for i in range(4)]
# skills_layers.append(skills_clusters_layered.select("industries").rdd.map(lambda x: x["industries"]).collect())
# skills_tnse = skills_clusters_layered.select(f"TNSE_vector").rdd.map(lambda x: np.array(x["TNSE_vector"])).collect()
# skills_sentences = skills_clusters_layered.select(f"sentence").rdd.map(lambda x: x["sentence"]).collect()

skills_layers = [[row[f"layer_{i}"] for row in skills_clusters_layered.select(f"layer_{i}").collect()] for i in range(4)]
skills_tnse = [np.array(row.TNSE_vector) for row in skills_clusters_layered.select("TNSE_vector").collect()]
skills_sentences = [np.array(row.sentence) for row in skills_clusters_layered.select("sentence").collect()]

# COMMAND ----------

save_to_pickle(skills_layers, "skills_layers.pickle")
save_to_pickle(skills_tnse, "skills_tnse.pickle")
save_to_pickle(skills_sentences, "skills_sentences.pickle")

# COMMAND ----------

split(source="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/skills_layers.pickle",
    dest_dir="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/skills_layers_parts/", 
    files_name="skills_layers_part")

# COMMAND ----------

split(source="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/skills_tnse.pickle",
    dest_dir="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/skills_tnse_parts/", 
    files_name="skills_tnse_part")

# COMMAND ----------

split(source="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/skills_sentences.pickle",
    dest_dir="/Workspace/Users/vladklim@campus.technion.ac.il/Project/models/skills_sentences_parts/", 
    files_name="skills_sentences_part")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Exploring the clustering results

# COMMAND ----------

largest_clusters = [x[0] for x in sorted(Counter(skills_sclusters_list).items(), key=lambda item: item[1], reverse=True)][:20]

# COMMAND ----------

visualize_tsne_clusters(skills_tnse_vectors, skills_clusters_list, skills_probs_list,
                        soft_clusters=skills_sclusters_list, soft_probs=skills_sprobs_list, cent_prob=0.98,
                        satur_accent=500, show_noise=False, show_simplices=False, show_soft_clusters=True, annotate=True, 
                        clusters_to_show=largest_clusters, subtitle="Jobs skills - Technology, Information and Internet, top20 largest clusters", s=80, fontsize=20, fig_size=(12, 12))

# COMMAND ----------

sns.distplot(titles_clusterer.outlier_scores_[np.isfinite(titles_clusterer.outlier_scores_)], rug=True)

# COMMAND ----------

threshold = pd.Series(titles_clusterer.outlier_scores_).quantile(0.9)
outliers = np.where(titles_clusterer.outlier_scores_ > threshold)[0]
plt.figure(figsize=(10, 7))
pal = sns.color_palette('deep', 27)
colors = [sns.desaturate(pal[col], sat) for col, sat in zip(titles_clusterer.labels_,
                                                            titles_clusterer.probabilities_)]
plt.scatter(titles_tnse_vectors.T[0], titles_tnse_vectors.T[1], c=colors, alpha=0.5)
# plt.scatter(*titles_tnse_vectors.T, s=50, linewidth=0, c='gray', alpha=0.25)
plt.scatter(*titles_tnse_vectors[outliers].T, s=50, linewidth=0, c='red', alpha=1)

# COMMAND ----------

titles_clusters.display()

# COMMAND ----------

skills_clusters_full_denoised_fix.select("soft_cluster").groupBy("soft_cluster").agg(F.count("soft_cluster")).orderBy(F.desc("count(soft_cluster)")).display()

# COMMAND ----------

window_spec = Window.partitionBy('soft_cluster').orderBy(F.desc(F.col('soft_probability')))
max_sim_df = titles_clusters.select("*", F.row_number().over(window_spec).alias('row_number'))
max_sim_rows = max_sim_df.filter(F.col('row_number').isin([1, 2, 3, 4, 5]))
max_sim_rows.select("sentence", "cluster", "soft_cluster", "probability", "soft_probability").display()

# COMMAND ----------

skills_clusters_full_denoised_fix.select("sentence", "soft_cluster", "cluster", "probability", "soft_probability").filter(F.col("soft_cluster") \
                .isin([84])).orderBy("soft_cluster", F.desc("soft_probability")).orderBy(F.desc("probability")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC # Not relevant

# COMMAND ----------

companies = spark.read.parquet('/linkedin/companies')
tech_comps = companies.join(jobs_parsed_df, ("url"), "inner")